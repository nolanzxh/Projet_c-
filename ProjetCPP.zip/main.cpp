#include <Windows.h>
#include <string>
#include <tchar.h>
#include <strsafe.h>
#include <iostream>
#include <exception>


#include "MyConsole.h"
#include "Body.h"
#include "BodyManager.h"

using namespace std;

int main()
{
//	LPCTSTR title = (LPCTSTR)"Game";
	
	MyConsole c;
	int begin1;
	c.set_title("game");
	c.set_dimensions(82, 25);
    begin1=MessageBox(0,"Press  'a d'  or  '<- ->'  to move the board!","GAME BEGIN", MB_OKCANCEL);
	if (begin1 == IDCANCEL) return 0;
	c.startGame();
	system("pause");
	return 0;
}