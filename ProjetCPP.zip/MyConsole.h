#pragma once
#include <Windows.h>

#include <conio.h>
#include "Console.h"

#include "Body.h"
#include "BodyManager.h"
class MyConsole :public Console{
   int over;
public:
	MyConsole();
	~MyConsole();

	void onKeyPressed(WORD keyCode);
	int startGame();

	BodyManager *bm;//barre
	Body *board;
	Position *board_pos;
	Box *wb;//ball
	Body *ball;
	Position *ball_pos;
	//Body *bodys[39][2];
	
	int ballVecX, ballVecY;//����˶��ٶ� vitess du ball
	
};

