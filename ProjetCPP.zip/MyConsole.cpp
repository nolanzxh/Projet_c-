#include "MyConsole.h"
#include <ctime>
MyConsole *g_myC;

#define PI 3.1415926


void ColBoard()
{

	//��ӵ������˶� �峤Ϊ10
	if (g_myC->ball->getPosition().y >= g_myC->board->getPosition().y - g_myC->ball->getBox().height
		&& g_myC->ball->getPosition().y <= g_myC->board->getPosition().y + g_myC->board->getBox().height)
	{
		//�ڰ����ಿ�ֽӵ�0-2��ԭ·����
		if (g_myC->ball_pos->x >= g_myC->board->getPosition().x
			&& g_myC->ball_pos->x < g_myC->board->getPosition().x + 2)
		{
			g_myC->ballVecY = -g_myC->ballVecY;
			g_myC->ballVecX = -g_myC->ballVecX;
		}//��������
		else if (g_myC->ball_pos->x >= g_myC->board->getPosition().x + 2
			&& g_myC->ball_pos->x <= g_myC->board->getPosition().x + 4)
		{
			g_myC->ballVecY = -g_myC->ballVecY;
			//if (g_myC->ballVecX == 0)
			//	g_myC->ballVecX = -1;
		}
		//ֱ��ֱ��
		else if (g_myC->ball_pos->x > g_myC->board->getPosition().x + 4
			&& g_myC->ball_pos->x < g_myC->board->getPosition().x + 6)
		{
			g_myC->ballVecY = -g_myC->ballVecY;
			g_myC->ballVecX = 0;
		}//��������
		else if (g_myC->ball_pos->x >= g_myC->board->getPosition().x + 6
			&& g_myC->ball_pos->x <= g_myC->board->getPosition().x + 8)
		{
			g_myC->ballVecY = -g_myC->ballVecY;
			//g_myC->ballVecX =0;
		}//ԭ·�����Ҳ�
		else if (g_myC->ball_pos->x > g_myC->board->getPosition().x + 8
			&& g_myC->ball_pos->x <= g_myC->board->getPosition().x + 10)
		{
			g_myC->ballVecY = -g_myC->ballVecY;
			g_myC->ballVecX = -g_myC->ballVecX;
		}
	}
}

DWORD CALLBACK ThreadProc(PVOID pvoid)
{
	Sleep(500);
	Body *b;// = new Body("", Box(2, 1), Position(0, 0), "��");
	int newX, newY;
	while (1)
	{//ש�����
		if (g_myC->bm->count <= 0)
		{
			g_myC->clear();
			
			MessageBox(NULL, "You WIN!", "GAME", 0);
			return 0;
			//g_myC->put_string("Passed!", 130, 130);
			break;
		}
		if (!g_myC->bm->fitBody(*g_myC->ball, *g_myC->ball_pos, &b))
		{
			if (b != NULL)
			{
				if (b->getName() != g_myC->board->getName())//��שͷ������ײ
				{
					b->disabled = TRUE;
					b->requestDraw = TRUE;
					g_myC->ballVecY = -g_myC->ballVecY;
					g_myC->ballVecX = g_myC->ballVecX;
					b->draw();
					g_myC->bm->count--;
				}
			}
			else
			{//
				g_myC->ballVecX = -g_myC->ballVecX;
			}

		}

		newX = g_myC->ball_pos->x + g_myC->ballVecX;
		newY = g_myC->ball_pos->y + g_myC->ballVecY;

	//�������߽�
		if (newX <= 0 || newX >= g_myC->wb->width)
		{
			g_myC->ballVecX = -g_myC->ballVecX;
		}

		g_myC->ball_pos->x = g_myC->ball->getPosition().x + g_myC->ballVecX;

		if (newY < 0)
			g_myC->ballVecY = -g_myC->ballVecY;
		g_myC->ball_pos->y = g_myC->ball->getPosition().y + g_myC->ballVecY;

		g_myC->bm->moveBody(*g_myC->ball, *g_myC->ball_pos);
		g_myC->ball->draw();
		//d�����Ƿ�ӵ���
		int d = (int)g_myC->ball->getPosition().y - (int)g_myC->board_pos->y;
		if (d > 0)
		{
			g_myC->clear();
			
			MessageBox(NULL, "You Lose!", "GAME", 0);
			return 0;
			//g_myC->put_string("FAILED!", 130, 130);
			break;
		}
		ColBoard();

		Sleep(100);
	}

	return 0;
}

MyConsole::MyConsole()
{
	board_pos = new Position(35, 23);
	ball_pos = new Position(39, 22);
	ballVecX = -1;
	ballVecY = -1;
	over = 0;
}


MyConsole::~MyConsole()
{
}

void MyConsole::onKeyPressed(WORD key)
{
	//����˶�
	switch (key)
	{
	case '%':
	case 'A':
	case 'a':
		if (board_pos->x > 2)
		{
			board_pos->x = board_pos->x - 2;
			board->requestDraw = TRUE;
			bm->moveBody(*board, *board_pos);
		}
		break;
	case '\'':
	case 'D':
	case 'd':
		if (board_pos->x < wb->width - 2&& board_pos->x+10<=78)
		{
			board_pos->x = board_pos->x + 2;
			board->requestDraw = TRUE;
			bm->moveBody(*board, *board_pos);
		}
		break;
	
	default:
		break;
	}
}

int MyConsole::startGame(){	

		set_pen_color(blue);
		Box box(2, 1);
		wb = new Box(this->getWidth(), this->getHeight());
		bm = new BodyManager(*wb, *this);

		bm->count = 0;

		for (unsigned short i = 0; i <= 78; i += 2)
		{
			for (unsigned short j = 0; j < 3; j += 2)
			{
				Body *body = new Body("body", box, Position(i, j), "��");

				bm->addBody(*body);
				bm->count++;
			}
		}

		board = new Body("board", Box(10, 1), *board_pos, "�{�{�{�{�{");
		bm->addBody(*board);

		ball = new Body("boll", Box(2, 1), *ball_pos, /*"\5"*/"��");
		bool f = bm->addBody(*ball);


		g_myC = this;

		/*function CreateThread(
  lpThreadAttributes: Pointer;           {��ȫ����}
  dwStackSize: DWORD;                    {��ջ��С}
  lpStartAddress: TFNThreadStartRoutine; {��ں���}
  lpParameter: Pointer;                  {��������}
  dwCreationFlags: DWORD;                {����ѡ��}
  var lpThreadId: DWORD                  {����߳� ID }
): THandle; stdcall;                     {�����߳̾��}*/

		DWORD dwThreadId;
		HANDLE hThread = CreateThread(NULL, 0, ThreadProc, 0, 0, &dwThreadId);
		
			bm->run();
		
		//DWORD dw = WaitForSingleObject(hThread, 0);
		//if (dw != WAIT_OBJECT_0)
		//bm->quit();
		
		return 0;
	
}


